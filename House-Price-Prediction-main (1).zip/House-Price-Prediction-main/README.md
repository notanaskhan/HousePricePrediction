# House-Price-Prediction
This project is being made using Tkinter for GUI and SQlite for the database.
